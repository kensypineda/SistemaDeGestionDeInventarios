import java.util.ArrayList;

public class Inventario {
    private ArrayList<Producto> productos;
    private ArrayList<Categoria> categorias;
    private ArrayList<Proveedor> proveedores;

    public Inventario() {
        productos = new ArrayList<>();
        categorias = new ArrayList<>();
        proveedores = new ArrayList<>();
    }

    public void agregarProducto(Producto producto, Categoria categoria, Proveedor proveedor) {
        productos.add(producto);
        categoria.añadirProducto(producto);
        proveedor.añadirProducto(producto);
    }

    public void agregarCategoria(Categoria categoria) {
        categorias.add(categoria);
    }

    public void agregarProveedor(Proveedor proveedor) {
        proveedores.add(proveedor);
    }

    public ArrayList<String> generarAlertas(int cantidadMinima) {
        ArrayList<String> alertas = new ArrayList<>();
        for (Producto producto : productos) {
            if (producto.getStock() < cantidadMinima) {
                alertas.add("¡Alerta! Stock bajo para " + producto.getNombre() + " - Stock: " + producto.getStock());
            }
        }
        return alertas;
    }
}
