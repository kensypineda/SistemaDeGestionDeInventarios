import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Inventario inventario = new Inventario();

        while (true) {
            System.out.println("\n=== Gestión de Inventarios ===");
            System.out.println("1. Añadir producto");
            System.out.println("2. Añadir categoría");
            System.out.println("3. Añadir proveedor");
            System.out.println("4. Generar alertas");
            System.out.println("5. Salir");
            System.out.print("Selecciona una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    
                    System.out.print("Nombre del producto: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Stock inicial: ");
                    int stock = scanner.nextInt();
                    System.out.print("Precio: ");
                    double precio = scanner.nextDouble();
                    scanner.nextLine(); 
                    System.out.print("Categoría del producto: ");
                    String categoriaNombre = scanner.nextLine();
                    System.out.print("Proveedor del producto: ");
                    String proveedorNombre = scanner.nextLine();

                    Categoria categoria = new Categoria(categoriaNombre);
                    Proveedor proveedor = new Proveedor(proveedorNombre, "Contacto desconocido");
                    Producto producto = new Producto(nombre, stock, precio);
                    inventario.agregarProducto(producto, categoria, proveedor);

                    System.out.println("Producto añadido con éxito.");
                    break;

                case 2:
                    
                    System.out.print("Nombre de la categoría: ");
                    String nuevaCategoria = scanner.nextLine();
                    inventario.agregarCategoria(new Categoria(nuevaCategoria));
                    System.out.println("Categoría añadida con éxito.");
                    break;

                case 3:
                    
                    System.out.print("Nombre del proveedor: ");
                    String nuevoProveedor = scanner.nextLine();
                    System.out.print("Contacto del proveedor: ");
                    String contacto = scanner.nextLine();
                    inventario.agregarProveedor(new Proveedor(nuevoProveedor, contacto));
                    System.out.println("Proveedor añadido con éxito.");
                    break;

                case 4:
                    
                    System.out.print("Introduce el stock mínimo: ");
                    int cantidadMinima = scanner.nextInt();
                    scanner.nextLine(); 
                    for (String alerta : inventario.generarAlertas(cantidadMinima)) {
                        System.out.println(alerta);
                    }
                    break;

                case 5:
                    System.out.println("¡Gracias por usar el sistema!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Opción no válida. Inténtalo de nuevo.");
            }
        }
    }
}
